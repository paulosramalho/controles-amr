import express from "express";
import cors from "cors";
import morgan from "morgan";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());
app.use(morgan("dev"));

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", message: "Controles-AMR backend ativo" });
});

// Placeholder de rotas básicas
app.get("/api/clients", (req, res) => {
  // TODO: listar clientes a partir das tabelas (banco de dados)
  res.json([]);
});

app.get("/api/payments", (req, res) => {
  // TODO: listar pagamentos efetuados pelos clientes
  res.json([]);
});

app.get("/api/lawyers", (req, res) => {
  // TODO: listar advogados e saldos a receber
  res.json([]);
});

app.get("/api/config/calculation-models", (req, res) => {
  // TODO: ler modelos de cálculo de percentuais a partir das tabelas de configuração
  res.json([]);
});

// Login (placeholder)
app.post("/api/auth/login", (req, res) => {
  // TODO: validar usuário e senha usando tabelas de usuários/perfis
  res.status(501).json({ message: "Login ainda não implementado." });
});

app.listen(PORT, () => {
  console.log(`Controles-AMR backend rodando na porta ${PORT}`);
});